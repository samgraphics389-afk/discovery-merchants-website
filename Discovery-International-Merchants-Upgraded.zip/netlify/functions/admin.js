const crypto = require('crypto');
function sign(payload, secret) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  return body + '.' + sig;
}
function verify(token, secret) {
  try {
    const [body, sig] = token.split('.');
    const expected = crypto.createHmac('sha256', secret).update(body).digest('base64url');
    if (sig !== expected) return null;
    const payload = JSON.parse(Buffer.from(body, 'base64url'));
    return payload.exp > Date.now() ? payload : null;
  } catch { return null; }
}
exports.handler = async (event) => {
  const secret = process.env.ADMIN_SECRET || 'change-this-admin-secret';
  const password = process.env.ADMIN_PASSWORD || '1234';
  if (event.httpMethod === 'POST') {
    const body = JSON.parse(event.body || '{}');
    if (body.action === 'login') {
      if (body.password !== password) return { statusCode: 401, body: JSON.stringify({ error: 'Incorrect password' }) };
      return { statusCode: 200, body: JSON.stringify({ token: sign({ exp: Date.now() + 8 * 60 * 60 * 1000 }, secret) }) };
    }
    return { statusCode: 400, body: 'Bad request' };
  }
  const token = (event.headers.authorization || '').replace('Bearer ', '');
  if (!verify(token, secret)) return { statusCode: 401, body: JSON.stringify({ error: 'Unauthorized' }) };
  const data = { cars: [], enquiries: [], customers: [] };
  const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (url && key) {
    try {
      for (const table of ['cars', 'enquiries']) {
        const r = await fetch(url + '/rest/v1/' + table + '?select=*&order=created_at.desc', { headers: { apikey: key, Authorization: 'Bearer ' + key } });
        if (r.ok) data[table] = await r.json();
      }
      const r = await fetch(url + '/auth/v1/admin/users?page=1&per_page=100', { headers: { apikey: key, Authorization: 'Bearer ' + key } });
      if (r.ok) {
        const users = await r.json();
        data.customers = (users.users || []).map(u => ({ email: u.email, name: u.user_metadata?.full_name || '', created: u.created_at }));
      }
    } catch {}
  }
  return { statusCode: 200, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) };
};
