const crypto=require('crypto');
function verify(token,secret){try{const [body,sig]=token.split('.');const expected=crypto.createHmac('sha256',secret).update(body).digest('base64url');if(sig!==expected)return false;const p=JSON.parse(Buffer.from(body,'base64url'));return p.exp>Date.now()}catch{return false}}
const headers={'Content-Type':'application/json','Access-Control-Allow-Origin':'*'};
exports.handler=async(event)=>{
 const url=process.env.SUPABASE_URL,key=process.env.SUPABASE_SERVICE_ROLE_KEY,bucket=process.env.CAR_PHOTOS_BUCKET||'car-photos';
 if(event.httpMethod==='OPTIONS')return{statusCode:204,headers};
 if(event.httpMethod==='GET'){if(!url||!key)return{statusCode:200,headers,body:JSON.stringify({cars:[]})};try{const r=await fetch(`${url}/rest/v1/cars?select=*&order=created_at.desc`,{headers:{apikey:key,Authorization:`Bearer ${key}`}});return{statusCode:r.status,headers,body:JSON.stringify({cars:r.ok?await r.json():[]})}}catch{return{statusCode:500,headers,body:JSON.stringify({error:'Unable to load inventory'})}}}
 const token=(event.headers.authorization||'').replace('Bearer ','');if(!verify(token,process.env.ADMIN_SECRET||'change-this-admin-secret'))return{statusCode:401,headers,body:JSON.stringify({error:'Unauthorized'})};
 if(!url||!key)return{statusCode:503,headers,body:JSON.stringify({error:'Cloud storage is not configured. Use demo mode or configure Supabase.'})};
 try{const b=JSON.parse(event.body||'{}');
 if(b.action==='upload'){const data=String(b.data||'');const match=data.match(/^data:image\/(jpeg|png|webp);base64,(.+)$/);if(!match)return{statusCode:400,headers,body:JSON.stringify({error:'Choose a JPG, PNG or WEBP image'})};if(match[2].length>5*1024*1024)return{statusCode:413,headers,body:JSON.stringify({error:'Image is too large. Compress it and try again.'})};const ext=match[1]==='jpeg'?'jpg':match[1];const file=`${Date.now()}-${crypto.randomBytes(5).toString('hex')}.${ext}`;const raw=Buffer.from(match[2],'base64');const up=await fetch(`${url}/storage/v1/object/${bucket}/${file}`,{method:'POST',headers:{apikey:key,Authorization:`Bearer ${key}`,'Content-Type':`image/${match[1]}`,'x-upsert':'true'},body:raw});if(!up.ok)return{statusCode:up.status,headers,body:JSON.stringify({error:await up.text()})};return{statusCode:200,headers,body:JSON.stringify({image:`${url}/storage/v1/object/public/${bucket}/${file}`})}}
 if(b.action==='save'){const car=b.car||{};const r=await fetch(`${url}/rest/v1/cars`,{method:'POST',headers:{apikey:key,Authorization:`Bearer ${key}`,'Content-Type':'application/json',Prefer:'resolution=merge-duplicates,return=representation'},body:JSON.stringify({...car,id:car.id||`car-${Date.now()}`})});return{statusCode:r.status,headers,body:JSON.stringify(await r.json())}}
 if(b.action==='delete'){const r=await fetch(`${url}/rest/v1/cars?id=eq.${encodeURIComponent(b.id)}`,{method:'DELETE',headers:{apikey:key,Authorization:`Bearer ${key}`}});return{statusCode:r.status,headers,body:JSON.stringify({ok:r.ok})}}
 return{statusCode:400,headers,body:JSON.stringify({error:'Unknown action'})};
 }catch(e){return{statusCode:500,headers,body:JSON.stringify({error:e.message})}}
};
